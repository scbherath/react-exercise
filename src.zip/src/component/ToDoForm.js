// import React , {useState} from 'react';

// const ToDoForm = ({handleButton}) => {

//     const [task, setTask] = useState('')
    
//     const hangleChange = (e) => {
//         setTask(e.target.value)
//     }
     
//     return (
//         <div>
//             <form onSubmit={handleButton}>
//                 <input type='text' name='todo_name' value={task} onChange={hangleChange} />
//                 <button type='submit' >add</button>
//             </form>  
//         </div>
//     )
// }

// export default ToDoForm;