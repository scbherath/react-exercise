// import React from 'react';

// const ViewDoTo = ({todos}) => {
//     return (
//         <div>            
//             <h4>To Do List </h4>
//             <h5>To Do Count : {parseInt(todos.length)} </h5>
//             {
//                 todos && todos.map((item,i)=>(
//                     <div>
//                         <div key={i}>{item}</div>xxx
//                         <button className='btn btn-success'>Remove</button>
//                     </div>
//                 ))
//             }
//         </div>
//     )
// }

// export default ViewDoTo;